# Zavier Gaines
# July 7 2025
# P4LAB1_GainesZavier
# draws a triangle and a square using loops 

import turtle





# set up the screen
wn = turtle.Screen()
wn.bgcolor("white")
wn.title("Triangle and Square")



# make a turtle
t = turtle.Turtle()
t.pensize(3)

# draw a triangle
for side in range(3):
    t.forward(100)
    t.left(120)
  
# move to a slightly overlapping spot
t.penup()
t.goto(50, -20)   # small shift so shapes overlap naturally
t.pendown()

# draw a square
for side in range(4):
    t.forward(100)
    t.left(90)

# keep the window open
wn.mainloop()
